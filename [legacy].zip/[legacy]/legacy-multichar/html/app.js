const app = document.getElementById('app');
const list = document.getElementById('list');

function post(name, data={}){
  return fetch(`https://${GetParentResourceName()}/${name}`,{
    method:'POST',
    headers:{'Content-Type':'application/json; charset=UTF-8'},
    body: JSON.stringify(data)
  }).then(r=>r.json()).catch(()=>({ok:false}));
}

function render(chars){
  list.innerHTML = '';
  (chars||[]).forEach(c=>{
    const el = document.createElement('div');
    el.className = 'item';
    el.innerHTML = `
      <div>
        <div><b>${c.name || ('CID '+c.cid)}</b></div>
        <div class="meta">${(c.job && c.job.name) ? (c.job.name + ' • grade ' + (c.job.grade||0)) : 'No job'}</div>
      </div>
      <button>Select</button>
    `;
    el.querySelector('button').addEventListener('click', ()=>post('select',{cid:c.cid}));
    list.appendChild(el);
  });
}

window.addEventListener('message', (e)=>{
  const d = e.data || {};
  if (d.action === 'open') app.classList.remove('hidden');
  if (d.action === 'close') app.classList.add('hidden');
  if (d.action === 'setCharacters') render(d.characters);
});

document.getElementById('createBtn').addEventListener('click', ()=>{
  post('create', {
    firstname: document.getElementById('fn').value,
    lastname: document.getElementById('ln').value,
    dob: document.getElementById('dob').value,
    gender: document.getElementById('gender').value
  });
});

document.getElementById('closeBtn').addEventListener('click', ()=>post('close',{}));
