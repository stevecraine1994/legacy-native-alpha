local isOpen = false
local function openUI()
  if isOpen then return end
  isOpen = true
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'open' })
  TriggerServerEvent('legacy-multichar:server:getCharacters')
end

local function closeUI()
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action = 'close' })
end

RegisterNetEvent('legacy-multichar:client:open', openUI)
RegisterNetEvent('legacy-multichar:client:close', closeUI)
RegisterNetEvent('legacy-multichar:client:refresh', function()
  TriggerServerEvent('legacy-multichar:server:getCharacters')
end)

RegisterNetEvent('legacy-multichar:client:characters', function(chars)
  SendNUIMessage({ action = 'setCharacters', characters = chars })
end)

RegisterNUICallback('select', function(data, cb)
  TriggerServerEvent('legacy-multichar:server:selectCharacter', data.cid)
  cb({ ok = true })
end)

RegisterNUICallback('create', function(data, cb)
  TriggerServerEvent('legacy-multichar:server:createCharacter', data)
  cb({ ok = true })
end)

RegisterNUICallback('close', function(_, cb)
  closeUI()
  cb({ ok = true })
end)

AddEventHandler('onClientResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  -- Open on start if not already logged in (Legacy core can set a statebag later)
  CreateThread(function()
    Wait(1500)
    openUI()
  end)
end)

-- QB compatibility event (client)
RegisterNetEvent('qb-multicharacter:client:chooseChar', openUI)
