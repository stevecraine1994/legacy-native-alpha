local Legacy = exports['legacy-core']:GetCore()

-- QB parity callback name (common pattern)
-- Clients can request their character list.
RegisterNetEvent('legacy-multichar:server:getCharacters', function()
  local src = source
  local identifiers = GetPlayerIdentifiers(src)
  local license
  for _, id in ipairs(identifiers) do
    if id:find('license:') == 1 then license = id break end
  end
  if not license then
    TriggerClientEvent('legacy-multichar:client:characters', src, {})
    return
  end

  local rows = MySQL.query.await('SELECT cid, name, job, metadata FROM legacy_characters WHERE license=? ORDER BY cid ASC', { license }) or {}
  local chars = {}
  for _, r in ipairs(rows) do
    local job = {}
    pcall(function() job = json.decode(r.job or '{}') end)
    local meta = {}
    pcall(function() meta = json.decode(r.metadata or '{}') end)
    chars[#chars+1] = {
      cid = r.cid,
      name = r.name,
      job = job,
      metadata = meta
    }
  end

  TriggerClientEvent('legacy-multichar:client:characters', src, chars)
end)

RegisterNetEvent('legacy-multichar:server:selectCharacter', function(cid)
  local src = source
  cid = tonumber(cid)
  if not cid then return end

  -- Expect legacy-core to expose a LoadCharacter / Login equivalent.
  if Legacy and Legacy.Functions and Legacy.Functions.LoadCharacter then
    Legacy.Functions.LoadCharacter(src, cid)
  end

  TriggerClientEvent('legacy-multichar:client:close', src)
end)

RegisterNetEvent('legacy-multichar:server:createCharacter', function(data)
  local src = source
  data = data or {}
  local firstname = tostring(data.firstname or '')
  local lastname = tostring(data.lastname or '')
  if firstname == '' or lastname == '' then return end

  if Legacy and Legacy.Functions and Legacy.Functions.CreateCharacter then
    Legacy.Functions.CreateCharacter(src, {
      firstname = firstname,
      lastname = lastname,
      dob = tostring(data.dob or ''),
      gender = tostring(data.gender or 'U')
    })
  end

  TriggerClientEvent('legacy-multichar:client:refresh', src)
end)

RegisterCommand('logout', function(src)
  if src == 0 then return end
  if Legacy and Legacy.Functions and Legacy.Functions.Logout then
    Legacy.Functions.Logout(src)
  end
  TriggerClientEvent('legacy-multichar:client:open', src)
end, false)

-- QB compatibility events (minimal)
RegisterNetEvent('qb-multicharacter:server:GetCharacters', function()
  TriggerEvent('legacy-multichar:server:getCharacters')
end)
