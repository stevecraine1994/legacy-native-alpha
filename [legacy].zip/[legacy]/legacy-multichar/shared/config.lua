LegacyMultichar = {
  MaxSlots = 4,
  DefaultSpawn = vector4(-1037.7, -2737.9, 20.17, 329.5), -- LSIA
}
