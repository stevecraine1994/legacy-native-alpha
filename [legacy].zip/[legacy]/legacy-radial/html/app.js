const app=document.getElementById('app');
function post(name,data={}){return fetch(`https://${GetParentResourceName()}/${name}`,{method:'POST',headers:{'Content-Type':'application/json; charset=UTF-8'},body:JSON.stringify(data)}).then(r=>r.json());}
window.addEventListener('message',(e)=>{const d=e.data||{}; if(d.action==='open') app.classList.remove('hidden'); if(d.action==='close') app.classList.add('hidden');});
document.querySelectorAll('.seg').forEach(b=>{
  b.addEventListener('click', ()=>{
    const act=b.getAttribute('data-act');
    if(act==='close'){ post('close',{}); return; }
    post('select',{action:act});
  });
});
