fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-radial'
author 'Legacy Framework'
description 'Legacy Radial Menu (QB parity)'
version '1.0.0'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js',
}

client_scripts {
  'client/main.lua',
}

dependencies {
  'legacy-core',
  'legacy-menu',
}
