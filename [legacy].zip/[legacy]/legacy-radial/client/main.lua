local isOpen = false

RegisterKeyMapping('legacyRadial', 'Open Radial Menu', 'keyboard', 'F1')
RegisterCommand('legacyRadial', function()
  isOpen = not isOpen
  SetNuiFocus(isOpen, isOpen)
  SendNUIMessage({ action = isOpen and 'open' or 'close' })
end, false)

RegisterNUICallback('close', function(_, cb)
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action='close' })
  cb({ ok=true })
end)

RegisterNUICallback('select', function(data, cb)
  local act = data.action
  if act == 'inventory' then
    TriggerEvent('legacy-inventory:client:openInventory')
  elseif act == 'phone' then
    TriggerEvent('legacy-phone:client:open')
  elseif act == 'citystats' then
    TriggerEvent('legacy-public:client:open')
  end
  cb({ ok=true })
end)

-- QB compat event
RegisterNetEvent('qb-radialmenu:client:openMenu', function()
  ExecuteCommand('legacyRadial')
end)
