local Core = LegacyCore

local pending = {}
local nextId = 1

function Core.Functions.GetPlayerData()
  local st = LocalPlayer and LocalPlayer.state
  local d = st and st.LegacyPlayerData or nil
  return d or {}
end

-- Basic HasItem stub for target checks (inventory module will replace this)
function Core.Functions.HasItem(item)
  -- until legacy-inventory exists, always false unless item == nil
  if not item then return true end
  return false
end

-- NUI/Legacy libs often expect a notify event name.
RegisterNetEvent('Legacy:Notify', function(msg, ntype)
  msg = tostring(msg or '')
  ntype = tostring(ntype or 'info')
  -- default: print to chat/console (replace with proper UI later)
  TriggerEvent('chat:addMessage', { args = { '[Legacy]', msg } })
end)

-- Optional: accept QBCore:Notify so older UI libs still show something
RegisterNetEvent('QBCore:Notify', function(msg, ntype)
  TriggerEvent('Legacy:Notify', msg, ntype)
end)

-- Callback client helper
function Core.Functions.TriggerCallback(name, cb, ...)
  local id = nextId
  nextId = nextId + 1
  pending[id] = cb
  TriggerServerEvent('Legacy:Server:TriggerCallback', name, id, ...)
end

RegisterNetEvent('Legacy:Client:CallbackResult', function(requestId, result)
  local cb = pending[requestId]
  if cb then
    pending[requestId] = nil
    cb(result)
  end
end)

RegisterNetEvent('Legacy:Client:OnPlayerLoaded', function(data)
  -- nothing required; statebag already set by server
end)

RegisterNetEvent('Legacy:Client:OnPlayerUnload', function()
  -- nothing required
end)
