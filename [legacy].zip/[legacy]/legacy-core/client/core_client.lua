local LegacyCore = {}
LegacyCore.Functions = {}

local function getPlayerData()
  local st = LocalPlayer and LocalPlayer.state and LocalPlayer.state.LegacyPlayerData
  return st
end

function LegacyCore.Functions.GetPlayerData()
  return getPlayerData() or {}
end

-- Inventory is not implemented in Native Alpha; return false to be safe
function LegacyCore.Functions.HasItem(item)
  return false
end

-- Simple notifications (fallback)
RegisterNetEvent('Legacy:Notify', function(msg, ntype, length)
  msg = tostring(msg or '')
  BeginTextCommandThefeedPost('STRING')
  AddTextComponentSubstringPlayerName(msg)
  EndTextCommandThefeedPostTicker(false, (tonumber(length) or 2500))
end)

-- Provide QB-style notify event name as an alias (many UI libs use it)
RegisterNetEvent('QBCore:Notify', function(msg, ntype, length)
  TriggerEvent('Legacy:Notify', msg, ntype, length)
end)

-- Re-broadcast state changes for legacy UI libs
RegisterNetEvent('Legacy:Client:OnPlayerLoaded', function(pdata)
  -- no-op; consumers can listen to this
end)

RegisterNetEvent('Legacy:Client:OnPlayerUnload', function()
  -- no-op
end)

RegisterNetEvent('Legacy:Client:OnJobUpdate', function(job)
  local pd = getPlayerData() or {}
  pd.job = job
  LocalPlayer.state:set('LegacyPlayerData', pd, true)
end)

RegisterNetEvent('Legacy:Client:OnGangUpdate', function(gang)
  local pd = getPlayerData() or {}
  pd.gang = gang
  LocalPlayer.state:set('LegacyPlayerData', pd, true)
end)

exports('GetCore', function()
  return LegacyCore
end)
