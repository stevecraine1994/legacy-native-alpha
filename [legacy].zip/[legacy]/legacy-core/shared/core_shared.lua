Legacy = Legacy or {}
Legacy.Functions = Legacy.Functions or {}

-- Simple deep copy (tables only)
local function clone(t)
  if type(t) ~= 'table' then return t end
  local o = {}
  for k,v in pairs(t) do o[k] = clone(v) end
  return o
end
Legacy.Functions._clone = clone

-- Common helper
Legacy.Functions.Print = function(msg)
  print(('^2[Legacy]^7 %s'):format(tostring(msg)))
end
