LegacyCore = LegacyCore or {}
LegacyCore.Functions = LegacyCore.Functions or {}
LegacyCore.Players = LegacyCore.Players or {}

function LegacyCore.Functions.DeepCopy(t)
  if type(t) ~= 'table' then return t end
  local r = {}
  for k,v in pairs(t) do r[k] = LegacyCore.Functions.DeepCopy(v) end
  return r
end
