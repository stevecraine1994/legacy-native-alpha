LegacyConfig = {
  Brand = {
    Name = 'Legacy',
    Edition = 'LA Underground Edition'
  },
  DefaultJob = {
    name = 'unemployed',
    label = 'Civilian',
    type = 'civ',
    grade = { level = 0, name = 'Unemployed' }
  },
  DefaultGang = {
    name = 'none',
    label = 'No Gang',
    grade = { level = 0, name = 'None' }
  }
}
