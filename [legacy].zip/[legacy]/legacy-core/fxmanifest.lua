fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-core'
author 'Legacy Framework'
description 'Legacy Native Core (Path B)'
version '0.1.0'

shared_scripts {
  'shared/config.lua',
  'shared/core_shared.lua'
}

client_scripts {
  'client/core_client.lua'
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/core_server.lua'
}

exports {
  'GetCore'
}

server_exports {
  'GetCore'
}

dependencies {
  'oxmysql'
}
