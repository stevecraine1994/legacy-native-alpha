local Core = LegacyCore

local function getLicense(src)
  for _, id in ipairs(GetPlayerIdentifiers(src)) do
    if id:sub(1,8) == 'license:' then return id end
  end
  return nil
end

local function now()
  return os.time()
end

local function safeDecode(s)
  if not s or s == '' then return {} end
  local ok, v = pcall(json.decode, s)
  if ok and type(v) == 'table' then return v end
  return {}
end

local function safeEncode(t)
  local ok, v = pcall(json.encode, t)
  if ok then return v end
  return '{}'
end

local function buildPlayerData(src, charRow)
  local job = safeDecode(charRow.job)
  local gang = safeDecode(charRow.gang)
  local meta = safeDecode(charRow.metadata)
  local money = safeDecode(charRow.money)

  if not job.name then job = LegacyConfig.DefaultJob end
  if not gang.name then gang = LegacyConfig.DefaultGang end
  money.cash = tonumber(money.cash or 0) or 0
  money.bank = tonumber(money.bank or 0) or 0

  local name = charRow.name
  if not name or name == '' then
    name = (charRow.firstname or 'Unknown') .. ' ' .. (charRow.lastname or 'Citizen')
  end

  return {
    source = src,
    license = charRow.license,
    cid = tonumber(charRow.cid),
    citizenid = tostring(charRow.cid),
    name = name,
    charinfo = {
      firstname = charRow.firstname or '',
      lastname = charRow.lastname or '',
      birthdate = charRow.dob or '',
      gender = charRow.gender or 'U'
    },
    job = job,
    gang = gang,
    money = money,
    metadata = meta,
  }
end

local function setPlayerState(src, data)
  local p = Player(src)
  if p and p.state then
    p.state:set('LegacyPlayerData', data, true)
    p.state:set('LegacyLoggedIn', true, true)
  end
end

local function clearPlayerState(src)
  local p = Player(src)
  if p and p.state then
    p.state:set('LegacyPlayerData', nil, true)
    p.state:set('LegacyLoggedIn', false, true)
  end
end

local function makePlayerObject(src, data)
  local self = {}
  self.PlayerData = data
  self.Functions = {}

  function self.Functions.SetJob(job)
    self.PlayerData.job = job
    setPlayerState(src, self.PlayerData)
    TriggerClientEvent('Legacy:Client:OnJobUpdate', src, job)
    TriggerEvent('Legacy:Server:OnJobUpdate', src, job)
  end

  function self.Functions.SetGang(gang)
    self.PlayerData.gang = gang
    setPlayerState(src, self.PlayerData)
    TriggerClientEvent('Legacy:Client:OnGangUpdate', src, gang)
    TriggerEvent('Legacy:Server:OnGangUpdate', src, gang)
  end

  function self.Functions.SetMetaData(key, val)
    self.PlayerData.metadata = self.PlayerData.metadata or {}
    self.PlayerData.metadata[key] = val
    setPlayerState(src, self.PlayerData)
  end

  function self.Functions.AddMoney(kind, amount, reason)
    amount = tonumber(amount or 0) or 0
    if amount <= 0 then return false end
    self.PlayerData.money = self.PlayerData.money or { cash=0, bank=0 }
    self.PlayerData.money[kind] = tonumber(self.PlayerData.money[kind] or 0) + amount
    setPlayerState(src, self.PlayerData)
    TriggerEvent('legacy:analytics:log', { event='money_add', kind=kind, amount=amount, reason=reason or 'unknown' })
    return true
  end

  function self.Functions.RemoveMoney(kind, amount, reason)
    amount = tonumber(amount or 0) or 0
    if amount <= 0 then return false end
    self.PlayerData.money = self.PlayerData.money or { cash=0, bank=0 }
    local cur = tonumber(self.PlayerData.money[kind] or 0)
    if cur < amount then return false end
    self.PlayerData.money[kind] = cur - amount
    setPlayerState(src, self.PlayerData)
    TriggerEvent('legacy:analytics:log', { event='money_remove', kind=kind, amount=amount, reason=reason or 'unknown' })
    return true
  end

  function self.Functions.Save()
    local d = self.PlayerData
    MySQL.update.await('UPDATE legacy_characters SET job=?, gang=?, metadata=?, money=?, last_seen=? WHERE cid=?', {
      safeEncode(d.job or {}),
      safeEncode(d.gang or {}),
      safeEncode(d.metadata or {}),
      safeEncode(d.money or {}),
      now(),
      d.cid
    })
  end

  return self
end

function Core.Functions.GetPlayer(src)
  return Core.Players[src]
end

function Core.Functions.GetPlayerData(src)
  local p = Core.Functions.GetPlayer(src)
  return p and p.PlayerData or nil
end

function Core.Functions.CreateCharacter(src, data)
  data = data or {}
  local license = getLicense(src)
  if not license then return false end

  local firstname = tostring(data.firstname or '')
  local lastname  = tostring(data.lastname or '')
  if firstname == '' or lastname == '' then return false end

  local name = firstname .. ' ' .. lastname
  local job = safeEncode(LegacyConfig.DefaultJob)
  local gang = safeEncode(LegacyConfig.DefaultGang)
  local metadata = safeEncode({})
  local money = safeEncode({ cash = 0, bank = 0 })

  local ok = MySQL.insert.await('INSERT INTO legacy_characters (license, name, firstname, lastname, dob, gender, job, gang, metadata, money, created_at, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', {
    license,
    name,
    firstname,
    lastname,
    tostring(data.dob or ''),
    tostring(data.gender or 'U'),
    job,
    gang,
    metadata,
    money,
    now(),
    now()
  })

  TriggerEvent('legacy:analytics:log', { event='character_create', license=license })
  return ok ~= nil
end

function Core.Functions.LoadCharacter(src, cid)
  local license = getLicense(src)
  if not license then return false end

  local row = MySQL.single.await('SELECT * FROM legacy_characters WHERE cid=? AND license=? LIMIT 1', { cid, license })
  if not row then return false end

  -- ensure user record
  MySQL.insert.await('INSERT IGNORE INTO legacy_users (license, first_seen, last_seen) VALUES (?,?,?)', { license, now(), now() })
  MySQL.update.await('UPDATE legacy_users SET last_seen=? WHERE license=?', { now(), license })

  local data = buildPlayerData(src, row)
  local player = makePlayerObject(src, data)
  Core.Players[src] = player

  setPlayerState(src, data)

  TriggerClientEvent('Legacy:Client:OnPlayerLoaded', src, data)
  TriggerEvent('Legacy:Server:PlayerLoaded', src, data)
  TriggerEvent('legacy:analytics:log', { event='character_load', cid=data.cid })

  return true
end

function Core.Functions.Logout(src)
  local p = Core.Players[src]
  if p and p.Functions and p.Functions.Save then
    p.Functions.Save()
  end
  Core.Players[src] = nil
  clearPlayerState(src)
  TriggerClientEvent('Legacy:Client:OnPlayerUnload', src)
  TriggerEvent('Legacy:Server:PlayerUnload', src)
  TriggerEvent('legacy:analytics:log', { event='logout' })
end

AddEventHandler('playerDropped', function()
  local src = source
  local p = Core.Players[src]
  if p and p.Functions and p.Functions.Save then
    p.Functions.Save()
  end
  Core.Players[src] = nil
  clearPlayerState(src)
end)

-- Minimal callback system (server-side) for future modules
Core.ServerCallbacks = Core.ServerCallbacks or {}
function Core.Functions.CreateCallback(name, fn)
  Core.ServerCallbacks[name] = fn
end

RegisterNetEvent('Legacy:Server:TriggerCallback', function(name, requestId, ...)
  local src = source
  local cb = Core.ServerCallbacks[name]
  if not cb then
    TriggerClientEvent('Legacy:Client:CallbackResult', src, requestId, nil)
    return
  end
  cb(src, function(result)
    TriggerClientEvent('Legacy:Client:CallbackResult', src, requestId, result)
  end, ...)
end)
