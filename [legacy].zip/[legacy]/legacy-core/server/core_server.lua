local LegacyCore = {}
LegacyCore.Functions = {}
LegacyCore.Players = {}

local function getLicense(src)
  for _, id in ipairs(GetPlayerIdentifiers(src)) do
    if id:sub(1,8) == 'license:' then return id end
  end
  return nil
end

local function ensureUser(license)
  if not license then return end
  MySQL.insert.await('INSERT IGNORE INTO legacy_users (license, created_at, last_seen) VALUES (?, ?, ?)', { license, os.time(), os.time() })
  MySQL.update.await('UPDATE legacy_users SET last_seen=? WHERE license=?', { os.time(), license })
end

local function buildPlayerData(src, charRow)
  local cid = tonumber(charRow.cid)
  local firstname = charRow.firstname or ''
  local lastname = charRow.lastname or ''
  local name = charRow.name or (firstname .. ' ' .. lastname)

  local job = LegacyConfig.DefaultJob
  local gang = LegacyConfig.DefaultGang
  local meta = {}
  local money = { cash = 0, bank = 0 }

  pcall(function()
    if charRow.job and charRow.job ~= '' then job = json.decode(charRow.job) end
  end)
  pcall(function()
    if charRow.gang and charRow.gang ~= '' then gang = json.decode(charRow.gang) end
  end)
  pcall(function()
    if charRow.metadata and charRow.metadata ~= '' then meta = json.decode(charRow.metadata) end
  end)
  pcall(function()
    if charRow.money and charRow.money ~= '' then money = json.decode(charRow.money) end
  end)

  job = job or LegacyConfig.DefaultJob
  gang = gang or LegacyConfig.DefaultGang

  return {
    source = src,
    cid = cid,
    citizenid = ('L-%06d'):format(cid),
    name = name,
    firstname = firstname,
    lastname = lastname,
    dob = charRow.dob or '',
    gender = charRow.gender or 'U',
    job = job,
    gang = gang,
    metadata = meta,
    money = money
  }
end

local function setPlayerState(src, pdata)
  local p = Player(src)
  if p and p.state then
    p.state:set('LegacyPlayerData', pdata, true)
    p.state:set('LegacyCID', pdata.cid, true)
  end
end

local function makePlayerObject(src, pdata)
  local PlayerObj = {}
  PlayerObj.PlayerData = pdata
  PlayerObj.Functions = {}

  function PlayerObj.Functions.Save()
    local lic = getLicense(src)
    if not lic or not pdata or not pdata.cid then return end
    MySQL.update.await('UPDATE legacy_characters SET job=?, gang=?, metadata=?, money=?, last_seen=? WHERE cid=? AND license=?', {
      json.encode(pdata.job or LegacyConfig.DefaultJob),
      json.encode(pdata.gang or LegacyConfig.DefaultGang),
      json.encode(pdata.metadata or {}),
      json.encode(pdata.money or {cash=0,bank=0}),
      os.time(),
      pdata.cid,
      lic
    })
  end

  function PlayerObj.Functions.SetJob(job)
    pdata.job = job or LegacyConfig.DefaultJob
    setPlayerState(src, pdata)
    TriggerClientEvent('Legacy:Client:OnJobUpdate', src, pdata.job)
  end

  function PlayerObj.Functions.SetGang(gang)
    pdata.gang = gang or LegacyConfig.DefaultGang
    setPlayerState(src, pdata)
    TriggerClientEvent('Legacy:Client:OnGangUpdate', src, pdata.gang)
  end

  function PlayerObj.Functions.SetMetaData(key, val)
    pdata.metadata = pdata.metadata or {}
    pdata.metadata[key] = val
    setPlayerState(src, pdata)
  end

  function PlayerObj.Functions.AddMoney(account, amount, reason)
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    pdata.money = pdata.money or {cash=0,bank=0}
    pdata.money[account] = (tonumber(pdata.money[account]) or 0) + amount
    setPlayerState(src, pdata)
    return true
  end

  function PlayerObj.Functions.RemoveMoney(account, amount, reason)
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    pdata.money = pdata.money or {cash=0,bank=0}
    local cur = tonumber(pdata.money[account]) or 0
    if cur < amount then return false end
    pdata.money[account] = cur - amount
    setPlayerState(src, pdata)
    return true
  end

  return PlayerObj
end

-- Public exports
function LegacyCore.Functions.GetPlayer(src)
  return LegacyCore.Players[src]
end

function LegacyCore.Functions.GetPlayerData(src)
  local p = LegacyCore.Players[src]
  return p and p.PlayerData or nil
end

function LegacyCore.Functions.CreateCharacter(src, data)
  local lic = getLicense(src)
  if not lic then return end
  ensureUser(lic)
  data = data or {}
  local firstname = tostring(data.firstname or '')
  local lastname = tostring(data.lastname or '')
  local name = (firstname .. ' ' .. lastname):gsub('^%s+',''):gsub('%s+$','')
  if firstname == '' or lastname == '' then return end

  MySQL.insert.await('INSERT INTO legacy_characters (license, name, firstname, lastname, dob, gender, job, gang, metadata, money, created_at, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', {
    lic,
    name,
    firstname,
    lastname,
    tostring(data.dob or ''),
    tostring(data.gender or 'U'),
    json.encode(LegacyConfig.DefaultJob),
    json.encode(LegacyConfig.DefaultGang),
    json.encode({}),
    json.encode({cash=0,bank=0}),
    os.time(),
    os.time()
  })
end

function LegacyCore.Functions.LoadCharacter(src, cid)
  cid = tonumber(cid)
  if not cid then return false end
  local lic = getLicense(src)
  if not lic then return false end
  ensureUser(lic)

  local row = MySQL.single.await('SELECT * FROM legacy_characters WHERE cid=? AND license=? LIMIT 1', { cid, lic })
  if not row then return false end

  local pdata = buildPlayerData(src, row)
  local pobj = makePlayerObject(src, pdata)
  LegacyCore.Players[src] = pobj

  setPlayerState(src, pdata)

  TriggerClientEvent('Legacy:Client:OnPlayerLoaded', src, pdata)
  TriggerEvent('Legacy:Server:PlayerLoaded', src, pdata)
  return true
end

function LegacyCore.Functions.Logout(src)
  local p = LegacyCore.Players[src]
  if p and p.Functions and p.Functions.Save then
    p.Functions.Save()
  end
  LegacyCore.Players[src] = nil
  local pl = Player(src)
  if pl and pl.state then
    pl.state:set('LegacyPlayerData', nil, true)
    pl.state:set('LegacyCID', nil, true)
  end
  TriggerClientEvent('Legacy:Client:OnPlayerUnload', src)
  TriggerEvent('Legacy:Server:PlayerUnload', src)
end

-- Autosave on drop
AddEventHandler('playerDropped', function()
  local src = source
  if not src then return end
  LegacyCore.Functions.Logout(src)
end)

-- Basic /whoami command
RegisterCommand('legacy_whoami', function(src)
  if src == 0 then return end
  local pdata = LegacyCore.Functions.GetPlayerData(src)
  if not pdata then
    TriggerClientEvent('chat:addMessage', src, { args = { '[Legacy]', 'Not logged in.' } })
  else
    TriggerClientEvent('chat:addMessage', src, { args = { '[Legacy]', ('%s | %s'):format(pdata.name or 'Unknown', pdata.citizenid or '') } })
  end
end, false)

-- Export
exports('GetCore', function()
  return LegacyCore
end)

-- Keep a global for other resources that prefer it
_G.LegacyCore = LegacyCore
