fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-smallresources'
author 'Legacy Framework'
description 'Legacy Small Resources (QB parity)'
version '1.0.0'

shared_scripts {
  'shared/config.lua',
}

client_scripts {
  'client/seatbelt.lua',
  'client/handsup.lua',
  'client/afk.lua',
  'client/main.lua',
}

dependencies {
  'legacy-core',
}
