local beltOn = false

AddEventHandler('legacy-smallresources:client:seatbelt', function()
  local ped = PlayerPedId()
  if not IsPedInAnyVehicle(ped, false) then return end
  beltOn = not beltOn
  if beltOn then
    TriggerEvent('chat:addMessage', { args = { 'SYSTEM', 'Seatbelt: ON' } })
  else
    TriggerEvent('chat:addMessage', { args = { 'SYSTEM', 'Seatbelt: OFF' } })
  end
end)

CreateThread(function()
  while true do
    Wait(0)
    if beltOn then
      DisableControlAction(0, 75, true) -- disable exit vehicle
    end
  end
end)
