-- Minimal AFK warning kick hook (server kick can be added later)
local lastMove = GetGameTimer()
local warned = false

CreateThread(function()
  while true do
    Wait(1000)
    local ped = PlayerPedId()
    if IsPedOnFoot(ped) then
      local speed = GetEntitySpeed(ped)
      if speed > 0.1 or IsControlPressed(0, 32) or IsControlPressed(0, 33) or IsControlPressed(0, 34) or IsControlPressed(0, 35) then
        lastMove = GetGameTimer()
        warned = false
      end
    end

    local idle = (GetGameTimer() - lastMove) / 1000
    if idle > 600 and not warned then
      warned = true
      TriggerEvent('chat:addMessage', { args = { 'SYSTEM', 'AFK warning: move or you may be kicked.' } })
    end
  end
end)
