local handsUp = false

AddEventHandler('legacy-smallresources:client:handsup', function(state)
  handsUp = state
  local ped = PlayerPedId()
  if handsUp then
    RequestAnimDict('missminuteman_1ig_2')
    while not HasAnimDictLoaded('missminuteman_1ig_2') do Wait(0) end
    TaskPlayAnim(ped, 'missminuteman_1ig_2', 'handsup_base', 8.0, -8.0, -1, 49, 0, false, false, false)
  else
    ClearPedTasks(ped)
  end
end)
