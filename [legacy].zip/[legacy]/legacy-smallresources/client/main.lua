-- key mappings
RegisterKeyMapping('+legacySeatbelt', 'Toggle Seatbelt', 'keyboard', LegacySmall.SeatbeltKey or 'B')
RegisterKeyMapping('+legacyHandsUp', 'Hands Up', 'keyboard', LegacySmall.HandsUpKey or 'X')

RegisterCommand('+legacySeatbelt', function() TriggerEvent('legacy-smallresources:client:seatbelt') end, false)
RegisterCommand('-legacySeatbelt', function() end, false)

RegisterCommand('+legacyHandsUp', function() TriggerEvent('legacy-smallresources:client:handsup', true) end, false)
RegisterCommand('-legacyHandsUp', function() TriggerEvent('legacy-smallresources:client:handsup', false) end, false)
