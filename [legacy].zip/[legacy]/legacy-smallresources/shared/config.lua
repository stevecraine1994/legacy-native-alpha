LegacySmall = { SeatbeltKey = 'B', HandsUpKey = 'X' }
