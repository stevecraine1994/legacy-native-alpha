---
name: Support
about: Ask for support on a problem.
title: "[SUPPORT]"
labels: help wanted
assignees: ''

---

**Problem:**
Explain the problem here

**Wanted Outcome:**
Explain here what you want it to do

**Current Point:**
All information about where you are now with your problem goes here

**Screenshots:**
If applicable, add screenshots to help explain your problem

**Additional context:**
Add any other context about the problem here
