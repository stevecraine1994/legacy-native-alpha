function Load(name)
	local resourceName = GetCurrentResourceName()
	local chunk = LoadResourceFile(resourceName, ('data/%s.lua'):format(name))
	if chunk then
		local err
		chunk, err = load(chunk, ('@@%s/data/%s.lua'):format(resourceName, name), 't')
		if err then
			error(('\n^1 %s'):format(err), 0)
		end
		return chunk()
	end
end

-------------------------------------------------------------------------------
-- Settings
-------------------------------------------------------------------------------

Config = {}

-- It's possible to interact with entities through walls so this should be low
Config.MaxDistance = 7.0

-- Enable debug options
Config.Debug = false

-- Supported values: true, false
Config.Standalone = false

-- Enable outlines around the entity you're looking at
Config.EnableOutline = false

-- Whether to have the target as a toggle or not
Config.Toggle = false

-- Draw a Sprite on the center of a PolyZone to hint where it's located
Config.DrawSprite = true

-- The default distance to draw the Sprite
Config.DrawDistance = 10.0

-- The color of the sprite in rgb, the first value is red, the second value is green, the third value is blue and the last value is alpha (opacity). Here is a link to a color picker to get these values: https://htmlcolorcodes.com/color-picker/
Config.DrawColor = { 255, 255, 255, 255 }

-- The color of the sprite in rgb when the PolyZone is targeted, the first value is red, the second value is green, the third value is blue and the last value is alpha (opacity). Here is a link to a color picker to get these values: https://htmlcolorcodes.com/color-picker/
Config.SuccessDrawColor = { 220, 20, 60, 255 }

-- The color of the outline in rgb, the first value is red, the second value is green, the third value is blue and the last value is alpha (opacity). Here is a link to a color picker to get these values: https://htmlcolorcodes.com/color-picker/
Config.OutlineColor = { 255, 255, 255, 255 }

-- Enable default options (Toggling vehicle doors)
Config.EnableDefaultOptions = true

-- Disable the target eye whilst being in a vehicle
Config.DisableInVehicle = false

-- Key to open the target eye, here you can find all the names: https://docs.fivem.net/docs/game-references/input-mapper-parameter-ids/keyboard/
Config.OpenKey = 'LMENU' -- Left Alt

-- Control for key press detection on the context menu, it's the Right Mouse Button by default, controls are found here https://docs.fivem.net/docs/game-references/controls/
Config.MenuControlKey = 238

-- Whether to disable ALL controls or only specificed ones
Config.DisableControls = true

-------------------------------------------------------------------------------
-- Target Configs
-------------------------------------------------------------------------------

-- These are all empty for you to fill in, refer to the .md files for help in filling these in

Config.CircleZones = {

}

Config.BoxZones = {

}

Config.PolyZones = {

}

Config.TargetBones = {

}

Config.TargetModels = {

}

Config.GlobalPedOptions = {

}

Config.GlobalVehicleOptions = {

}

Config.GlobalObjectOptions = {

}

Config.GlobalPlayerOptions = {

}

Config.Peds = {

}

-------------------------------------------------------------------------------
-- Functions
-------------------------------------------------------------------------------
local function JobCheck() return true end
local function GangCheck() return true end
local function JobTypeCheck() return true end
local function ItemCheck() return true end
local function CitizenCheck() return true end

CreateThread(function()
  -- Legacy Native: always use legacy-core (no qb-core dependency)
  if Config.Standalone then
    local firstSpawn = false
    local event = AddEventHandler('playerSpawned', function()
      SpawnPeds()
      firstSpawn = true
    end)
    while true do
      if firstSpawn then
        RemoveEventHandler(event)
        break
      end
      Wait(1000)
    end
    return
  end

  local Core = exports['legacy-core']:GetCore()
  local PlayerData = Core.Functions.GetPlayerData() or {}

  ItemCheck = function(item)
    if Core.Functions.HasItem then
      return Core.Functions.HasItem(item)
    end
    return true
  end

  JobCheck = function(job)
    PlayerData = Core.Functions.GetPlayerData() or PlayerData
    local pj = PlayerData.job or { name = 'unemployed', grade = { level = 0 }, type = 'civ' }
    if type(job) == 'table' then
      local req = job[pj.name]
      if req and (pj.grade and (pj.grade.level or 0) >= req) then
        return true
      end
    elseif job == 'all' or job == pj.name then
      return true
    end
    return false
  end

  JobTypeCheck = function(jobType)
    PlayerData = Core.Functions.GetPlayerData() or PlayerData
    local pj = PlayerData.job or { type = 'civ' }
    if type(jobType) == 'table' then
      return jobType[pj.type] and true or false
    elseif jobType == 'all' or jobType == pj.type then
      return true
    end
    return false
  end

  GangCheck = function(gang)
    PlayerData = Core.Functions.GetPlayerData() or PlayerData
    local pg = PlayerData.gang or { name = 'none', grade = { level = 0 } }
    if type(gang) == 'table' then
      local req = gang[pg.name]
      if req and (pg.grade and (pg.grade.level or 0) >= req) then
        return true
      end
    elseif gang == 'all' or gang == pg.name then
      return true
    end
    return false
  end

  CitizenCheck = function(citizenid)
    PlayerData = Core.Functions.GetPlayerData() or PlayerData
    local cid = PlayerData.citizenid
    return cid and (citizenid == cid or (type(citizenid) == 'table' and citizenid[cid]))
  end

  RegisterNetEvent('Legacy:Client:OnPlayerLoaded', function()
    PlayerData = Core.Functions.GetPlayerData() or {}
    SpawnPeds()
  end)

  RegisterNetEvent('Legacy:Client:OnPlayerUnload', function()
    PlayerData = {}
    DeletePeds()
  end)

  RegisterNetEvent('Legacy:Client:OnJobUpdate', function(JobInfo)
    PlayerData.job = JobInfo
  end)

  RegisterNetEvent('Legacy:Client:OnGangUpdate', function(GangInfo)
    PlayerData.gang = GangInfo
  end)

  RegisterNetEvent('Legacy:Player:SetPlayerData', function(val)
    PlayerData = val
  end)
end)


function CheckOptions(data, entity, distance)
	if distance and data.distance and distance > data.distance then return false end
	if data.job and not JobCheck(data.job) then return false end
	if data.excludejob and JobCheck(data.excludejob) then return false end
	if data.jobType and not JobTypeCheck(data.jobType) then return false end
	if data.excludejobType and JobTypeCheck(data.excludejobType) then return false end
	if data.gang and not GangCheck(data.gang) then return false end
	if data.excludegang and GangCheck(data.excludegang) then return false end
	if data.item and not ItemCheck(data.item) then return false end
	if data.citizenid and not CitizenCheck(data.citizenid) then return false end
	if data.canInteract and not data.canInteract(entity, distance, data) then return false end
	return true
end
