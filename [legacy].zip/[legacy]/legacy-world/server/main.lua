local state = {
  weather = 'EXTRASUNNY',
  time = { h = 12, m = 0 },
  freezeTime = false,
  blackout = false
}

CreateThread(function()
  while true do
    Wait(2000)
    if not state.freezeTime then
      state.time.m = state.time.m + 1
      if state.time.m >= 60 then
        state.time.m = 0
        state.time.h = (state.time.h + 1) % 24
      end
    end
    TriggerClientEvent('legacy-world:client:sync', -1, state)
  end
end)

RegisterCommand('weather', function(src, args)
  if src ~= 0 then return end
  local w = tostring(args[1] or ''):upper()
  if w == '' then return end
  state.weather = w
end)

RegisterCommand('time', function(src, args)
  if src ~= 0 then return end
  local h = tonumber(args[1]); local m = tonumber(args[2] or 0)
  if not h then return end
  state.time.h = math.max(0, math.min(23, h))
  state.time.m = math.max(0, math.min(59, m))
end)

RegisterCommand('freezetime', function(src)
  if src ~= 0 then return end
  state.freezeTime = not state.freezeTime
end)

-- QB compat events
RegisterNetEvent('qb-weathersync:server:setWeather', function(w) state.weather = tostring(w or 'EXTRASUNNY'):upper() end)
