fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-world'
author 'Legacy Framework'
description 'Legacy World Sync (QB weathersync parity)'
version '1.0.0'

server_scripts {
  'server/main.lua',
}

client_scripts {
  'client/main.lua',
}
