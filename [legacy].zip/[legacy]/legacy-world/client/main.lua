RegisterNetEvent('legacy-world:client:sync', function(s)
  if not s then return end
  SetWeatherTypePersist(s.weather)
  SetWeatherTypeNow(s.weather)
  SetWeatherTypeNowPersist(s.weather)
  NetworkOverrideClockTime(s.time.h, s.time.m, 0)
  SetArtificialLightsState(s.blackout)
end)

-- QB compat event
RegisterNetEvent('qb-weathersync:client:SyncWeather', function(s)
  TriggerEvent('legacy-world:client:sync', s)
end)
