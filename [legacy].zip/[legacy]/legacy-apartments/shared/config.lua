LegacyApartments = {
  Locations = {
    ['alta'] = {
      label='Alta Place',
      enter=vector3(-268.96, -961.6, 31.22),
      spawn=vector4(-271.14, -957.73, 31.22, 205.0)
    }
  }
}
