RegisterCommand('apartment', function(_, args)
  local ap = args[1]
  if ap and LegacyApartments.Locations[ap] then
    TriggerServerEvent('legacy-apartments:server:setApartment', ap)
    print('Apartment set:', ap)
  else
    print('Usage: /apartment alta')
  end
end, false)

RegisterNetEvent('legacy-apartments:client:apartment', function(apId)
  if not apId then return end
  local loc = LegacyApartments.Locations[apId]
  if not loc then return end
  local ped = PlayerPedId()
  SetEntityCoordsNoOffset(ped, loc.spawn.x, loc.spawn.y, loc.spawn.z, false, false, false)
  SetEntityHeading(ped, loc.spawn.w)
end)
