-- Apartment assignment persists on character metadata in legacy-core (recommended).
-- For parity we provide a simple getter/setter.

local Legacy = exports['legacy-core']:GetCore()

RegisterNetEvent('legacy-apartments:server:setApartment', function(apId)
  local src = source
  local Player = Legacy.Functions.GetPlayer(src)
  if not Player then return end
  Player.PlayerData.metadata = Player.PlayerData.metadata or {}
  Player.PlayerData.metadata.apartment = apId
  if Legacy.DB and Legacy.DB.SavePlayer then
    Legacy.DB.SavePlayer(Player)
  end
end)

RegisterNetEvent('legacy-apartments:server:getApartment', function()
  local src = source
  local Player = Legacy.Functions.GetPlayer(src)
  if not Player then
    TriggerClientEvent('legacy-apartments:client:apartment', src, nil)
    return
  end
  local ap = Player.PlayerData.metadata and Player.PlayerData.metadata.apartment or nil
  TriggerClientEvent('legacy-apartments:client:apartment', src, ap)
end)

-- QB compat
RegisterNetEvent('qb-apartments:server:SetApartment', function(apId) TriggerEvent('legacy-apartments:server:setApartment', apId) end)
RegisterNetEvent('qb-apartments:server:GetApartment', function() TriggerEvent('legacy-apartments:server:getApartment') end)
