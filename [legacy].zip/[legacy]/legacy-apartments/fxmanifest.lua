fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-apartments'
author 'Legacy Framework'
description 'Legacy Apartments (QB parity)'
version '1.0.0'

shared_scripts {
  'shared/config.lua',
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/main.lua',
}

client_scripts {
  'client/main.lua',
}

dependencies {
  'legacy-core',
}
