RegisterNetEvent('legacy-spawn:server:spawn', function(spawnId)
  local src = source
  TriggerClientEvent('legacy-spawn:client:spawn', src, spawnId)
end)

-- QB compatibility event names
RegisterNetEvent('qb-spawn:server:spawnPlayer', function(spawnId)
  TriggerEvent('legacy-spawn:server:spawn', spawnId)
end)
