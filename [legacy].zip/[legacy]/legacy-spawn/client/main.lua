local isOpen = false

local function openUI()
  if isOpen then return end
  isOpen = true
  SetNuiFocus(true, true)
  SendNUIMessage({ action='open' })
end

local function closeUI()
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action='close' })
end

RegisterNetEvent('legacy-spawn:client:open', openUI)
RegisterNetEvent('legacy-spawn:client:close', closeUI)

RegisterNetEvent('legacy-spawn:client:spawn', function(spawnId)
  local s = nil
  for _, sp in ipairs(LegacySpawn.Spawns) do
    if sp.id == spawnId then s = sp break end
  end
  if not s then s = LegacySpawn.Spawns[1] end

  DoScreenFadeOut(500)
  while not IsScreenFadedOut() do Wait(0) end

  local ped = PlayerPedId()
  local c = s.coords
  SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, false, false, false)
  SetEntityHeading(ped, c.w)

  FreezeEntityPosition(ped, false)
  DoScreenFadeIn(750)

  closeUI()
end)

RegisterNUICallback('spawn', function(data, cb)
  TriggerServerEvent('legacy-spawn:server:spawn', data.spawnId)
  cb({ ok=true })
end)

RegisterNUICallback('close', function(_, cb)
  closeUI()
  cb({ ok=true })
end)

AddEventHandler('onClientResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  CreateThread(function()
    Wait(2500)
    openUI()
    SendNUIMessage({ action='setSpawns', spawns=LegacySpawn.Spawns })
  end)
end)

RegisterNetEvent('qb-spawn:client:openUI', openUI)
