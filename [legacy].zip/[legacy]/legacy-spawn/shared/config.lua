LegacySpawn = {
  Spawns = {
    { id='lsia', label='Airport', coords=vector4(-1037.7, -2737.9, 20.17, 329.5) },
    { id='mrpd', label='Mission Row PD', coords=vector4(431.5, -981.9, 30.7, 90.0) },
    { id='pillbox', label='Pillbox Medical', coords=vector4(298.9, -584.5, 43.3, 70.0) },
  }
}
