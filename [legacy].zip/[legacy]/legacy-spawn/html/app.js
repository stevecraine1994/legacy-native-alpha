const app = document.getElementById('app');
const spawnsEl = document.getElementById('spawns');

function post(name, data={}){
  return fetch(`https://${GetParentResourceName()}/${name}`,{
    method:'POST',
    headers:{'Content-Type':'application/json; charset=UTF-8'},
    body: JSON.stringify(data)
  }).then(r=>r.json()).catch(()=>({ok:false}));
}

function render(spawns){
  spawnsEl.innerHTML='';
  (spawns||[]).forEach(s=>{
    const el=document.createElement('div');
    el.className='spawn';
    el.innerHTML=`<div>${s.label}</div><button>Spawn</button>`;
    el.querySelector('button').addEventListener('click', ()=>post('spawn',{spawnId:s.id}));
    spawnsEl.appendChild(el);
  });
}

window.addEventListener('message',(e)=>{
  const d=e.data||{};
  if(d.action==='open') app.classList.remove('hidden');
  if(d.action==='close') app.classList.add('hidden');
  if(d.action==='setSpawns') render(d.spawns);
});

document.getElementById('closeBtn').addEventListener('click', ()=>post('close',{}));
