fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'legacy-public'
author 'Legacy Framework'
description 'Legacy Public Dashboard (QB-scoreboard style)'
version '1.0.0'

ui_page 'html/ui.html'

files {
  'html/ui.html',
  'html/style.css',
  'html/app.js'
}

shared_scripts {
  'shared_config.lua'
}

client_scripts {
  'client/main.lua'
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/ratelimit.lua',
  'server/queries.lua',
  'server/main.lua'
}

dependencies {
  'oxmysql',
  'legacy-analytics'
}
