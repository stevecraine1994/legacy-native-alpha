LegacyPublicConfig = {
  Command = 'citystats',
  Key = 'F10',

  -- Dashboard items order + labels (QB-scoreboard style)
  Items = {
    CALLS_24H = 'Calls (24h)',
    AVG_RESPONSE = 'Avg Response',
    EVIDENCE_OK = 'Evidence Admissible',
    STOLEN_24H = 'Stolen Vehicles (24h)',
    IMPOUNDS_24H = 'Impounds (24h)',
    BUDGET_INDEX = 'City Budget Index',
  },

  -- Status thresholds (drives ✅/⏳/❌ style indicators)
  Thresholds = {
    AVG_RESPONSE_SEC = { ok = 300, warn = 600 }, -- <=5m ok, <=10m warn, else bad
    EVIDENCE_PCT = { ok = 90, warn = 75 },
    BUDGET_INDEX = { ok = 60, warn = 35 },
  },

  RefreshSeconds = 5, -- prevent spam; server enforces too
}
