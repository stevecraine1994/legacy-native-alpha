window.addEventListener('message', (event) => {
  switch (event.data.action) {
    case 'setup':
      setup(event.data);
      break;
    case 'open':
      openDash(event.data);
      break;
    case 'close':
      closeDash();
      break;
  }
});

const closeDash = () => {
  const block = document.querySelector('.scoreboard-block');
  if (block) block.style.display = 'none';
};

const setup = (data) => {
  const info = document.querySelector('.scoreboard-info');
  if (!info) return;
  info.innerHTML = '';

  // data.items is a map: KEY -> Label
  Object.entries(data.items || {}).forEach(([key, label]) => {
    const beam = document.createElement('div');
    beam.className = 'scoreboard-info-beam';
    beam.setAttribute('data-key', key);

    const title = document.createElement('div');
    title.className = 'info-beam-title';
    title.innerHTML = `<p>${label}</p>`;

    const status = document.createElement('div');
    status.className = 'info-beam-status';
    status.innerHTML = '<p>—</p>';

    beam.appendChild(title);
    beam.appendChild(status);
    info.appendChild(beam);
  });
};

const openDash = (data) => {
  const block = document.querySelector('.scoreboard-block');
  if (block) block.style.display = 'block';

  // Update footer: players
  const tp = document.getElementById('total-players');
  if (tp) tp.innerHTML = `<p>${data.players} of ${data.maxPlayers}</p>`;

  // Updated at
  const ua = document.getElementById('updated-at');
  if (ua && data.updatedAt) {
    const dt = new Date(data.updatedAt * 1000);
    ua.textContent = `Updated: ${dt.toLocaleString()}`;
  }

  // Update beams
  const items = data.items || {};
  Object.entries(items).forEach(([key, obj]) => {
    const beam = document.querySelector(`.scoreboard-info [data-key="${key}"]`);
    if (!beam) return;
    const status = beam.querySelector('.info-beam-status');
    if (!status) return;

    const icon = obj.status || 'ℹ️';
    const value = obj.value ?? '—';
    status.innerHTML = `<p>${icon} ${value}</p>`;
  });
};
