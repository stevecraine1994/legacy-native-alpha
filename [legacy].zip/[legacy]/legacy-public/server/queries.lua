LegacyPublic = LegacyPublic or {}
LegacyPublic.Queries = {}

local function getMetric(metric, period)
  local row = MySQL.single.await(
    'SELECT value, calculated_at FROM legacy_analytics WHERE metric=? AND period=? LIMIT 1',
    { metric, period }
  )
  if not row then return nil end
  return { value = tonumber(row.value) or 0, calculated_at = tonumber(row.calculated_at) or os.time() }
end

function LegacyPublic.Queries.GetSummary()
  local now = os.time()

  local avgResp = getMetric('AVG_RESPONSE_TIME', 'DAILY')
  local callVol = getMetric('CALL_VOLUME_24H', 'DAILY')
  local evPct   = getMetric('EVIDENCE_ADMISSIBLE_PCT', 'DAILY')
  local gov     = getMetric('GOV_BALANCE', 'DAILY')

  local stolen24 = MySQL.single.await(
    'SELECT COUNT(*) as c FROM legacy_vehicles WHERE stolen=1 AND created_at >= ?',
    { now - 86400 }
  )
  local imp24 = MySQL.single.await(
    'SELECT COUNT(*) as c FROM legacy_vehicle_impound WHERE impounded_at >= ?',
    { now - 86400 }
  )

  local budgetIndex = nil
  if gov then
    -- convert to public-safe index (0-100)
    budgetIndex = math.max(0, math.min(100, math.floor((gov.value / 1000000) * 10)))
  end

  return {
    updatedAt = now,
    avgResponseSec = avgResp and avgResp.value or 0,
    calls24h = callVol and callVol.value or 0,
    evidencePct = evPct and evPct.value or 100,
    stolen24h = stolen24 and tonumber(stolen24.c) or 0,
    impounds24h = imp24 and tonumber(imp24.c) or 0,
    budgetIndex = budgetIndex,
  }
end
