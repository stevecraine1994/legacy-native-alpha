local function fmtTime(sec)
  sec = math.max(0, math.floor(tonumber(sec) or 0))
  local m = math.floor(sec / 60)
  local s = sec % 60
  if m < 60 then return string.format('%dm %ds', m, s) end
  local h = math.floor(m / 60)
  local mm = m % 60
  return string.format('%dh %dm', h, mm)
end

local function statusForAvgResponse(sec)
  local th = LegacyPublicConfig.Thresholds.AVG_RESPONSE_SEC
  if sec <= th.ok then return '✅' end
  if sec <= th.warn then return '⏳' end
  return '❌'
end

local function statusForEvidence(pct)
  local th = LegacyPublicConfig.Thresholds.EVIDENCE_PCT
  if pct >= th.ok then return '✅' end
  if pct >= th.warn then return '⏳' end
  return '❌'
end

local function statusForBudget(idx)
  local th = LegacyPublicConfig.Thresholds.BUDGET_INDEX
  if idx >= th.ok then return '✅' end
  if idx >= th.warn then return '⏳' end
  return '❌'
end

RegisterNetEvent('legacy-public:server:GetPublicData', function()
  local src = source
  if not LegacyPublic.CanQuery(src, 'public', LegacyPublicConfig.RefreshSeconds or 5) then return end

  local s = LegacyPublic.Queries.GetSummary()
  local players = GetNumPlayerIndices()
  local maxPlayers = GetConvarInt('sv_maxclients', 48)

  local items = {
    CALLS_24H = { value = tostring(math.floor(s.calls24h or 0)), status = 'ℹ️' },
    AVG_RESPONSE = { value = fmtTime(s.avgResponseSec or 0), status = statusForAvgResponse(s.avgResponseSec or 0) },
    EVIDENCE_OK = { value = string.format('%d%%', math.floor(s.evidencePct or 100)), status = statusForEvidence(s.evidencePct or 100) },
    STOLEN_24H = { value = tostring(math.floor(s.stolen24h or 0)), status = 'ℹ️' },
    IMPOUNDS_24H = { value = tostring(math.floor(s.impounds24h or 0)), status = 'ℹ️' },
  }

  if s.budgetIndex ~= nil then
    items.BUDGET_INDEX = { value = string.format('%d/100', math.floor(s.budgetIndex)), status = statusForBudget(s.budgetIndex) }
  else
    items.BUDGET_INDEX = { value = 'N/A', status = 'ℹ️' }
  end

  TriggerClientEvent('legacy-public:client:OpenData', src, {
    players = players,
    maxPlayers = maxPlayers,
    updatedAt = s.updatedAt,
    items = items,
  })
end)
