LegacyPublic = LegacyPublic or {}
LegacyPublic._rate = LegacyPublic._rate or {}

function LegacyPublic.CanQuery(src, key, interval)
  interval = tonumber(interval or 5) or 5
  local now = os.time()
  LegacyPublic._rate[src] = LegacyPublic._rate[src] or {}
  local last = LegacyPublic._rate[src][key] or 0
  if (now - last) < interval then return false end
  LegacyPublic._rate[src][key] = now
  return true
end

AddEventHandler('playerDropped', function()
  LegacyPublic._rate[source] = nil
end)
