local isOpen = false

local function sendSetup()
  SendNUIMessage({ action = 'setup', items = LegacyPublicConfig.Items })
end

local function toggle()
  if not isOpen then
    TriggerServerEvent('legacy-public:server:GetPublicData')
  else
    SendNUIMessage({ action = 'close' })
    isOpen = false
  end
end

RegisterNetEvent('legacy-public:client:OpenData', function(data)
  -- QB-scoreboard style overlay: no NUI focus needed
  SendNUIMessage({
    action = 'open',
    players = data.players,
    maxPlayers = data.maxPlayers,
    updatedAt = data.updatedAt,
    items = data.items,
  })
  isOpen = true
end)

RegisterCommand(LegacyPublicConfig.Command or 'citystats', function()
  toggle()
end, false)

RegisterKeyMapping(LegacyPublicConfig.Command or 'citystats', 'Open City Public Dashboard', 'keyboard', LegacyPublicConfig.Key or 'F10')

CreateThread(function()
  Wait(750)
  sendSetup()
end)
