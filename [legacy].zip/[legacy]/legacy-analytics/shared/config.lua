LegacyAnalyticsConfig = {
  FlushSeconds = 10,
  MaxBuffer = 200
}
