local buffer = {}

local function push(row)
  buffer[#buffer+1] = row
  if #buffer >= (LegacyAnalyticsConfig.MaxBuffer or 200) then
    TriggerEvent('legacy-analytics:server:flush')
  end
end

RegisterNetEvent('legacy:analytics:log', function(payload)
  local src = source
  payload = payload or {}
  local event = tostring(payload.event or 'EVENT')
  local category = tostring(payload.category or 'general')
  local meta = payload.meta or {}

  push({
    ts = os.time(),
    src = tonumber(src) or 0,
    event = event,
    category = category,
    meta = json.encode(meta)
  })
end)

RegisterNetEvent('legacy-analytics:server:flush', function()
  if #buffer == 0 then return end
  local rows = buffer
  buffer = {}

  for _, r in ipairs(rows) do
    MySQL.insert('INSERT INTO legacy_event_log (ts, src, event, category, meta) VALUES (?,?,?,?,?)', {
      r.ts, r.src, r.event, r.category, r.meta
    })
  end
end)

CreateThread(function()
  while true do
    Wait((LegacyAnalyticsConfig.FlushSeconds or 10) * 1000)
    TriggerEvent('legacy-analytics:server:flush')

    -- Keep legacy-public from showing nil metrics by upserting safe defaults
    local now = os.time()
    MySQL.update('INSERT INTO legacy_analytics (metric, period, value, calculated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value), calculated_at=VALUES(calculated_at)', {
      'AVG_RESPONSE_TIME', 'DAILY', 0, now
    })
    MySQL.update('INSERT INTO legacy_analytics (metric, period, value, calculated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value), calculated_at=VALUES(calculated_at)', {
      'CALL_VOLUME_24H', 'DAILY', 0, now
    })
    MySQL.update('INSERT INTO legacy_analytics (metric, period, value, calculated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value), calculated_at=VALUES(calculated_at)', {
      'EVIDENCE_ADMISSIBLE_PCT', 'DAILY', 100, now
    })
    MySQL.update('INSERT INTO legacy_analytics (metric, period, value, calculated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value), calculated_at=VALUES(calculated_at)', {
      'GOV_BALANCE', 'DAILY', 0, now
    })
  end
end)
